document.addEventListener('DOMContentLoaded', function() {
    const convertBtn = document.getElementById('convertBtn');
    const container = document.getElementById('container');
    const currencySelects = document.querySelectorAll('#currency, #toCurrency');
    const currencyOptions = {
        'mm': '#cd7f32',
        'sm': '#c0c0c0',
        'em': '#7d8a9b',
        'zm': '#ffca43',
        'pm': '#e5e4e2'
    };

    // Применение стилей для выбора валют
    function applyCurrencyStyles() {
        const fromCurrency = document.getElementById('currency').value;
        const toCurrency = document.getElementById('toCurrency').value;

        // Удаление старых стилей
        currencySelects.forEach(select => select.classList.remove('option-mm', 'option-sm', 'option-em', 'option-zm', 'option-pm'));

        // Применение новых стилей
        const fromClass = `option-${fromCurrency}`;
        const toClass = `option-${toCurrency}`;
        document.querySelector('#currency').classList.add(fromClass);
        document.querySelector('#toCurrency').classList.add(toClass);

        // Анимация градиентов
        document.querySelector('#currency').style.transition = 'background-color 0.5s ease, color 0.5s ease';
        document.querySelector('#toCurrency').style.transition = 'background-color 0.5s ease, color 0.5s ease';
    }

    // Создание пузырьков
    function createBubbles(x, y) {
        const bubbleCount = 10;
        for (let i = 0; i < bubbleCount; i++) {
            const bubble = document.createElement('div');
            bubble.className = 'bubble bubble-small';
            bubble.style.left = `${x + Math.random() * 70 - 35}px`;
            bubble.style.top = `${y + Math.random() * 50 - 35}px`;
            container.appendChild(bubble);
            setTimeout(() => bubble.remove(), 1000);
        }
    }

    // Создание искорок
    function createSparks(x, y, color) {
        const sparkCount = 15;
        for (let i = 0; i < sparkCount; i++) {
            const spark = document.createElement('div');
            spark.className = 'spark';
            spark.style.width = `${Math.random() * 20 + 5}px`;
            spark.style.height = spark.style.width;
            spark.style.background = color;
            spark.style.left = `${x + Math.random() * 0 - 0}px`;
            spark.style.top = `${y + Math.random() * 0 - 0}px`;
            container.appendChild(spark);
            setTimeout(() => spark.remove(), 0);
        }
    }

    // Обработка клика на кнопку конвертации
    convertBtn.addEventListener('click', function(event) {
        const amount = parseFloat(document.getElementById('amount').value);
        const fromCurrency = document.getElementById('currency').value;
        const toCurrency = document.getElementById('toCurrency').value;

        if (isNaN(amount)) {
            document.getElementById('convertedAmount').innerText = 'Введите корректную сумму';
            return;
        }

        // Конверсионные коэффициенты
        const rates = {
            'mm': { 'mm': 1, 'sm': 0.1, 'em': 0.02, 'zm': 0.01, 'pm': 0.001 },
            'sm': { 'mm': 10, 'sm': 1, 'em': 0.2, 'zm': 0.1, 'pm': 0.01 },
            'em': { 'mm': 50, 'sm': 5, 'em': 1, 'zm': 0.5, 'pm': 0.05 },
            'zm': { 'mm': 100, 'sm': 10, 'em': 2, 'zm': 1, 'pm': 0.1 },
            'pm': { 'mm': 1000, 'sm': 100, 'em': 20, 'zm': 10, 'pm': 1 }
        };

        const convertedAmount = (amount * rates[fromCurrency][toCurrency]).toFixed(2);
        const currencyName = getCurrencyName(toCurrency);

        if (amount < 0) {
            document.getElementById('convertedAmount').innerText = `-${Math.abs(convertedAmount)} ${currencyName}`;
        } else {
            document.getElementById('convertedAmount').innerText = `${convertedAmount} ${currencyName}`;
        }

        // Анимация кнопки
        const buttonRect = convertBtn.getBoundingClientRect();
        const buttonX = buttonRect.left + (buttonRect.width / 2);
        const buttonY = buttonRect.top + (buttonRect.height / 2);

        createBubbles(buttonX, buttonY + window.scrollY);
        createSparks(buttonX, buttonY + window.scrollY, '#ff0');

        convertBtn.classList.add('shake');
        setTimeout(() => convertBtn.classList.remove('shake'), 500);

        // Применение стилей для выбора монет
        applyCurrencyStyles();
    });

    // Обработка выбора монеты
    document.querySelectorAll('.select-custom').forEach(select => {
        select.addEventListener('change', function() {
            const selectedOption = this.querySelector('option:checked');
            const selectedCurrency = selectedOption.value;

            // Создание искорок для выбранной монеты
            const optionRect = selectedOption.getBoundingClientRect();
            const optionX = optionRect.left + (optionRect.width / 2);
            const optionY = optionRect.top + (optionRect.height / 2);

            createSparks(optionX, optionY + window.scrollY, currencyOptions[selectedCurrency]);

            // Изменение цвета фона для выбранной монеты
            this.style.background = `linear-gradient(45deg, ${currencyOptions[selectedCurrency]} 0%, ${darkenColor(currencyOptions[selectedCurrency])} 100%)`;
            this.style.color = '#fff';

            // Анимация дрожания соседней монеты
            const adjacentCurrency = Array.from(this.options).find(option => option.value !== selectedCurrency && option.selected);
            if (adjacentCurrency) {
                const adjacentOption = document.querySelector(`option[value="${adjacentCurrency.value}"]`);
                if (adjacentOption) {
                    adjacentOption.classList.add('shake');
                    setTimeout(() => adjacentOption.classList.remove('shake'), 500);
                }
            }
        });
    });

    function darkenColor(color) {
        // Функция для затемнения цвета
        const hex = color.replace('#', '');
        const r = parseInt(hex.substring(0, 2), 16);
        const g = parseInt(hex.substring(2, 4), 16);
        const b = parseInt(hex.substring(4, 6), 16);
        const darken = (amount) => Math.max(0, Math.min(255, Math.round(amount * 0.8)));
        return `#${darken(r).toString(16).padStart(2, '0')}${darken(g).toString(16).padStart(2, '0')}${darken(b).toString(16).padStart(2, '0')}`;
    }

    function getCurrencyName(code) {
        const names = {
            'mm': 'Медные монеты (мм)',
            'sm': 'Серебряные монеты (см)',
            'em': 'Электровые монеты (эм)',
            'zm': 'Золотые монеты (зм)',
            'pm': 'Платиновые монеты (пм)'
        };
        return names[code];
    }
});
