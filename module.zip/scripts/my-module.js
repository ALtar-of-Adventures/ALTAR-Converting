Hooks.on('getSceneControlButtons', (controls) => {
    const tokenControls = controls.find(c => c.name === "token");
    const massEditControls = controls.find(c => c.name === "mass-edit");
    const currencyControl = {
        name: "Калькулятор Валюты",
        title: "Калькулятор Валюты",
        icon: 'fa-solid fa-coins',
        visible: true,
        button: true,
        onClick: () => openCalculatorDialog()
    };

    if (tokenControls) {
        tokenControls.tools.unshift(currencyControl); // Перемещаем иконку в начало списка
    }

    if (massEditControls) {
        massEditControls.tools.unshift(currencyControl); // Перемещаем иконку в начало списка
    }
});

// Функция должна быть доступна глобально
function openCalculatorDialog() {
    new Dialog({
        title: "Конвертер валюты · ALtar of Adventures🔥🐲",
        content: `<iframe id="jsdos" src="modules/converters-currencies/index.html" width="100%" height="690px"></iframe>`,
        buttons: {},
        render: (html) => {
            // В html передается jQuery объект, используем jQuery методы
            const iframe = html.find('#jsdos');
            if (iframe.length) {
                iframe.css('flex', '10%');
                iframe.focus();
            }
        }
    }, {
        height: 730,
        width: 742,
        classes: ["dialog", "dnd"],
        jQuery: true  // Убедитесь, что jQuery включен
    }).render(true);
}
